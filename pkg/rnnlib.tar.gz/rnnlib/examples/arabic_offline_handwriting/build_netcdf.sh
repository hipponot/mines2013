#! /bin/bash
./arabic_offline.py filenames.txt arabic_offline.nc

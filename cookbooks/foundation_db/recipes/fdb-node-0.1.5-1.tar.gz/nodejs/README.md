For complete FoundationDB Node.js documentation, visit http://alpha.foundationdb.com/documentation.

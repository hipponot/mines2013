#ifndef FDB_C_H
#define FDB_C_H
#pragma once

/*
 * FoundationDB C API
 * Copyright 2009-2012 FoundationDB, LLC. All Rights Reserved.
 * 
 * This is a confidential non-public alpha version of FoundationDB's software.
 * Participation in this alpha testing program is by invitation only and the
 * possession, use, and replication of the FoundationDB software is subject 
 * to the FoundationDB Alpha Software Evaluation License Agreement, which can 
 * be found at http://foundationdb.com/AlphaLicenseAgreement.pdf
 *
 * Documentation for this API can be found at 
 * http://alpha.foundationdb.com/documentation/api-c.html
 *
 * You must define FDB_API_VERSION before including this file:
 *   #define FDB_API_VERSION 14
 *   #include <foundationdb/fdb_c.h>
 */

#ifndef DLLEXPORT
#define DLLEXPORT
#endif

#if !defined(FDB_API_VERSION)
#error You must #define FDB_API_VERSION prior to including fdb_c.h (current version is 14)
#elif FDB_API_VERSION < 13
#error API version no longer supported (upgrade to 13)
#elif FDB_API_VERSION > 14
#error Requested API version requires a newer version of this header
#endif

#include <stdint.h>

#include "fdb_c_options.g.h"

#ifdef __cplusplus
extern "C" {
#endif

    /* Pointers to these opaque types represent objects in the FDB API */
    typedef struct future FDBFuture;
    typedef struct cluster FDBCluster;
    typedef struct database FDBDatabase;
    typedef struct transaction FDBTransaction;

    typedef int fdb_error_t;
    typedef int fdb_bool_t;

    DLLEXPORT const char*
    fdb_get_error( fdb_error_t code );

    #define /* fdb_error_t */ fdb_select_api_version(v) fdb_select_api_version_impl(v, FDB_API_VERSION)

    DLLEXPORT fdb_error_t
    fdb_network_set_option( FDBNetworkOption option, uint8_t const* value,
                            int value_length );

#if FDB_API_VERSION >= 14
    DLLEXPORT fdb_error_t fdb_setup_network();
#endif

    DLLEXPORT fdb_error_t fdb_run_network();

    DLLEXPORT fdb_error_t fdb_stop_network();

#pragma pack(push, 4)
    typedef struct keyvalue {
        const void* key;
        int key_length;
        const void* value;
        int value_length;
    } FDBKeyValue;
#pragma pack(pop)

    DLLEXPORT void fdb_future_destroy( FDBFuture* f );

    DLLEXPORT fdb_error_t fdb_future_block_until_ready( FDBFuture* f );

    DLLEXPORT fdb_bool_t fdb_future_is_ready( FDBFuture* f );

    DLLEXPORT fdb_bool_t fdb_future_is_error( FDBFuture* f );

    typedef void (*FDBCallback)(FDBFuture* future, void* callback_parameter);

    DLLEXPORT fdb_error_t
    fdb_future_set_callback( FDBFuture* f, FDBCallback callback,
                             void* callback_parameter );

    DLLEXPORT fdb_error_t
    fdb_future_get_error( FDBFuture* f,
                          const char** out_description /* = NULL */ );

    DLLEXPORT fdb_error_t
    fdb_future_get_version( FDBFuture* f, int64_t* out_version );

    DLLEXPORT fdb_error_t
    fdb_future_get_key( FDBFuture* f, uint8_t const** out_key,
                        int* out_key_length );

    DLLEXPORT fdb_error_t
    fdb_future_get_cluster( FDBFuture* f, FDBCluster** out_cluster );

    DLLEXPORT fdb_error_t
    fdb_future_get_database( FDBFuture* f, FDBDatabase** out_database );

    DLLEXPORT fdb_error_t
    fdb_future_get_value( FDBFuture* f, fdb_bool_t *out_present,
                          uint8_t const** out_value,
                          int* out_value_length );

#if FDB_API_VERSION >= 14
    DLLEXPORT fdb_error_t
    fdb_future_get_keyvalue_array( FDBFuture* f, FDBKeyValue const** out_kv,
                                   int* out_count, fdb_bool_t* out_more );
#endif

    DLLEXPORT FDBFuture* fdb_create_cluster( const char* cluster_file_path );

    DLLEXPORT void fdb_cluster_destroy( FDBCluster* c );

    DLLEXPORT fdb_error_t
    fdb_cluster_set_option( FDBCluster* c, FDBClusterOption option, 
                            uint8_t const* value, int value_length );

    DLLEXPORT FDBFuture*
    fdb_cluster_create_database( FDBCluster* c, uint8_t const* db_name,
                                 int db_name_length );

    DLLEXPORT void fdb_database_destroy( FDBDatabase* d );

    DLLEXPORT fdb_error_t
    fdb_database_set_option( FDBDatabase* d, FDBDatabaseOption option, 
                             uint8_t const* value, int value_length );

    DLLEXPORT fdb_error_t
    fdb_database_create_transaction( FDBDatabase* d,
                                     FDBTransaction** out_transaction );

    DLLEXPORT void fdb_transaction_destroy( FDBTransaction* tr);

#if FDB_API_VERSION >= 14
    DLLEXPORT fdb_error_t
    fdb_transaction_set_option( FDBTransaction* tr, FDBTransactionOption option,
                                uint8_t const* value, int value_length );
#endif

    DLLEXPORT void
    fdb_transaction_set_read_version( FDBTransaction* tr, int64_t version );

    DLLEXPORT FDBFuture* fdb_transaction_get_read_version( FDBTransaction* tr );

#if FDB_API_VERSION >= 14
    DLLEXPORT FDBFuture*
    fdb_transaction_get( FDBTransaction* tr, uint8_t const* key_name,
                         int key_name_length, fdb_bool_t snapshot );
#endif

#if FDB_API_VERSION >= 14
    DLLEXPORT FDBFuture*
    fdb_transaction_get_key( FDBTransaction* tr, uint8_t const* key_name,
                             int key_name_length, fdb_bool_t or_equal,
                             int offset, fdb_bool_t snapshot );
#endif

#if FDB_API_VERSION >= 14
    DLLEXPORT FDBFuture* fdb_transaction_get_range(
        FDBTransaction* tr, uint8_t const* begin_key_name,
        int begin_key_name_length, fdb_bool_t begin_or_equal, int begin_offset,
        uint8_t const* end_key_name, int end_key_name_length,
        fdb_bool_t end_or_equal, int end_offset, int limit, int target_bytes,
        FDBStreamingMode mode, int iteration, fdb_bool_t snapshot,
        fdb_bool_t reverse );
#endif

    DLLEXPORT void
    fdb_transaction_set( FDBTransaction* tr, uint8_t const* key_name,
                         int key_name_length, uint8_t const* value,
                         int value_length );

    DLLEXPORT void
    fdb_transaction_clear( FDBTransaction* tr, uint8_t const* key_name,
                           int key_name_length );

    DLLEXPORT void fdb_transaction_clear_range(
        FDBTransaction* tr, uint8_t const* begin_key_name,
        int begin_key_name_length, uint8_t const* end_key_name,
        int end_key_name_length );

    DLLEXPORT FDBFuture* fdb_transaction_commit( FDBTransaction* tr );

    DLLEXPORT fdb_error_t
    fdb_transaction_get_committed_version( FDBTransaction* tr,
                                           int64_t* out_version );

    DLLEXPORT FDBFuture*
    fdb_transaction_on_error( FDBTransaction* tr, fdb_error_t error );

    DLLEXPORT void fdb_transaction_reset( FDBTransaction* tr );

    #define FDB_KEYSEL_LAST_LESS_THAN(k, l) k, l, 0, 0
    #define FDB_KEYSEL_LAST_LESS_OR_EQUAL(k, l) k, l, 1, 0
    #define FDB_KEYSEL_FIRST_GREATER_THAN(k, l) k, l, 1, 1
    #define FDB_KEYSEL_FIRST_GREATER_OR_EQUAL(k, l) k, l, 0, 1

    DLLEXPORT fdb_error_t
    fdb_select_api_version_impl( int runtime_version, int header_version );

    DLLEXPORT int fdb_get_max_api_version();

    /* LEGACY API VERSIONS */

#if FDB_API_VERSION < 14
    DLLEXPORT fdb_error_t fdb_future_get_keyvalue_array(
        FDBFuture* f, FDBKeyValue const** out_kv, int* out_count );

    DLLEXPORT FDBFuture* fdb_transaction_get(
        FDBTransaction* tr, uint8_t const* key_name, int key_name_length );


    DLLEXPORT FDBFuture* fdb_transaction_get_key(
        FDBTransaction* tr, uint8_t const* key_name, int key_name_length,
        fdb_bool_t or_equal, int offset );

    DLLEXPORT fdb_error_t fdb_setup_network( const char* local_address );

    DLLEXPORT void fdb_transaction_set_option(
        FDBTransaction* tr, FDBTransactionOption option );

    DLLEXPORT FDBFuture* fdb_transaction_get_range(
        FDBTransaction* tr, uint8_t const* begin_key_name,
        int begin_key_name_length, uint8_t const* end_key_name,
        int end_key_name_length, int limit );

    DLLEXPORT FDBFuture* fdb_transaction_get_range_selector(
        FDBTransaction* tr, uint8_t const* begin_key_name,
        int begin_key_name_length, fdb_bool_t begin_or_equal,
        int begin_offset, uint8_t const* end_key_name,
        int end_key_name_length, fdb_bool_t end_or_equal, int end_offset,
        int limit );
#endif

#ifdef __cplusplus
}
#endif
#endif

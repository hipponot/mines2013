#ifndef FDB_C_TRANSACTION_OPTIONS_H
#define FDB_C_TRANSACTION_OPTIONS_H
#pragma once

typedef enum {
    // The address to which the client should bind. Either one of LOCAL_ADDRESS or FDB_CLUSTER_FILE should be specified.
    // Parameter: IP:PORT
    FDB_NET_OPTION_LOCAL_ADDRESS=10,

    // Sets the cluster file to parse so a network interface can be chosen for the client. This file is not used to connect to a cluster. Either one of LOCAL_ADDRESS or FDB_CLUSTER_FILE should be specified.
    // Parameter: path to cluster file
    FDB_NET_OPTION_CLUSTER_FILE=20,

    // Enables trace output to the working directory of the running process
    // Option takes no parameter
    FDB_NET_OPTION_TRACE_ENABLE=30
} FDBNetworkOption;

typedef enum {

} FDBClusterOption;

typedef enum {

} FDBDatabaseOption;

typedef enum {
    // The transaction, if not self-conflicting, may be committed a second time after commit succeeds, in the event of a fault
    // Option takes no parameter
    FDB_TR_OPTION_CAUSAL_WRITE_RISKY=10,

    // The read version will be committed, and usually will be the latest committed, but might not be the latest committed in the event of a fault or partition
    // Option takes no parameter
    FDB_TR_OPTION_CAUSAL_READ_RISKY=20,

    // 
    // Option takes no parameter
    FDB_TR_OPTION_CAUSAL_READ_DISABLE=21,

    // 
    // Option takes no parameter
    FDB_TR_OPTION_CHECK_WRITES_ENABLE=50,

    // 
    // Option takes no parameter
    FDB_TR_OPTION_READ_YOUR_WRITES_DISABLE=51,

    // 
    // Option takes no parameter
    FDB_TR_OPTION_READ_AHEAD_DISABLE=52,

    // 
    // Option takes no parameter
    FDB_TR_OPTION_DURABILITY_DATACENTER=110,

    // 
    // Option takes no parameter
    FDB_TR_OPTION_DURABILITY_RISKY=120,

    // 
    // Option takes no parameter
    FDB_TR_OPTION_DURABILITY_DEV_NULL_IS_WEB_SCALE=130,

    // Specifies that this transaction should be treated as highest priority and that lower priority transactions should block behind this one. Use is discouraged outside of low-level tools
    // Option takes no parameter
    FDB_TR_OPTION_PRIORITY_SYSTEM_IMMEDIATE=200,

    // Specifies that this transaction should be treated as low priority and that default priority transactions should be processed first. Useful for doing batch work simultaneously with latency-sensitive work
    // Option takes no parameter
    FDB_TR_OPTION_PRIORITY_BATCH=201,

    // This is a write-only transaction which sets the initial configuration
    // Option takes no parameter
    FDB_TR_OPTION_INITIALIZE_NEW_DATABASE=300,

    // 
    // Option takes no parameter
    FDB_TR_OPTION_DEBUG_DUMP=400
} FDBTransactionOption;

#endif

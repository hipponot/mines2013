# FoundationDB Python API
# Copyright 2009-2012 FoundationDB, LLC. All Rights Reserved.
#
# This is a confidential non-public alpha version of FoundationDB's
# software. Participation in this alpha testing program is by
# invitation only and the possession, use, and replication of the
# FoundationDB software is subject to the FoundationDB Alpha Software 
# Evaluation License Agreement, which can be found at
# http://foundationdb.com/AlphaLicenseAgreement.pdf

"""Documentation for this API can be found at 
http://alpha.foundationdb.com/documentation/api-python.html"""

def open(*args, **kwargs):
    raise RuntimeError('You must call api_version(14) before using any fdb methods')

init = open

def api_version(ver):
    if globals().has_key('_version'):
        if globals()['_version'] != ver:
            raise RuntimeError('FDB API already loaded at version %d' % _version)
        return

    if ver < 13:
        raise RuntimeError('FDB API versions before 13 are not supported')

    if ver > 14:
        raise RuntimeError('Latest known FDB API version is 14')

    import fdb.impl

    fdb.impl._capi.fdb_select_api_version_impl(ver, 14)

    list = (
        'FDBError',
        'Future',
        'Cluster',
        'Database',
        'Transaction',
        'KeyValue',
        'KeySelector',
        'init',
        'create_cluster',
        'open',
        'transactional',
        'options',
        'StreamingMode',
        )

    for sym in list:
        globals()[sym] = getattr(fdb.impl, sym)

    if ver == 13:
        globals()["open"] = getattr(fdb.impl, "open_v13")
        globals()["init"] = getattr(fdb.impl, "init_v13")

        # Future.get got renamed to Futur.wait in v14 to make room for
        # Database.get, we have to undo that here
        for name in dir(fdb.impl):
            o = getattr(fdb.impl, name)
            try:
                if issubclass(o, fdb.impl.Future):
                    if hasattr(o, "wait"):
                        o.get = o.wait
            except TypeError: pass

        # FDBRange used to be called FDBRangeIter and was an iterator,
        # but it's now a container. In v13 we have to make it act like
        # an iterator again.
        def next(self):
            if not hasattr(self, "__iterating"):
                self.__iterating = iter(self)
            return self.__iterating.next()
        setattr(fdb.impl.FDBRange, "next", next)

    globals()['_version'] = ver

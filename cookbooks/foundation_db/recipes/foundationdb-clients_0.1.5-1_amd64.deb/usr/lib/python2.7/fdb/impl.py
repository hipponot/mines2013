# FoundationDB Python API
# Copyright 2009-2012 FoundationDB, LLC. All Rights Reserved.
#
# This is a confidential non-public alpha version of FoundationDB's
# software. Participation in this alpha testing program is by
# invitation only and the possession, use, and replication of the
# FoundationDB software is subject to the FoundationDB Alpha Software 
# Evaluation License Agreement, which can be found at
# http://foundationdb.com/AlphaLicenseAgreement.pdf

import ctypes
import functools
import threading
import inspect
import datetime
import __builtin__

_network_thread = None
_open_file = open


import weakref

class _NetworkOptions(object):
    def __init__(self, parent):
        self._parent = parent

class _ClusterOptions(object):
    def __init__(self, cluster):
        self._parent = weakref.proxy(cluster)

class _DatabaseOptions(object):
    def __init__(self, db):
        self._parent = weakref.proxy(db)

class _TransactionOptions(object):
    def __init__(self, tr):
        self._parent = weakref.proxy(tr)


from fdb import fdboptions as _opts

def fill_options(scope):
    _dict = getattr(_opts, scope)
    
    for k,v in _dict.items():
        fname = 'set_' + k.lower()
        opt, param, desc = v
        def wrap(opt):
            def setfunc(self):
                self._parent._set_option(opt)
            return setfunc
        def wrap_param(opt):
            def setfunc(self, param):
                self._parent._set_option(opt, param)
            return setfunc
        f = param and wrap_param(opt) or wrap(opt)
        f.__name__ = fname
        f.__doc__ = desc
        if param is not None:
            f.__doc__ += '\n\nArgument is ' + param
        klass = globals()['_' + scope + 's']
        setattr(klass, fname, f)

for scope in ['ClusterOption', 'DatabaseOption', 'TransactionOption', 'NetworkOption']:
    fill_options(scope)

import sys
options = _NetworkOptions(sys.modules[__name__])

def _set_option(option, param=None):
    _capi.fdb_network_set_option(option, param, param and len(param) or 0)

def make_enum(scope):
    _dict = getattr(_opts, scope)

    x = type(scope, (), {})

    def makeprop(value, doc):
        return property( fget=lambda o:value, doc=doc )
    for k, v in _dict.items():
        setattr(x, k.lower(), makeprop( v[0], v[2] ))

    globals()[scope] = x()

make_enum("StreamingMode")


def transactional(*tr_args, **tr_kwargs):
    """Decorate a funcation as transactional.

    The decorator looks for a named argument (default 'tr') and takes
    one of two actions, depending on the type of the parameter passed
    to the function at call time.

    If given a Database, a Transaction will be created and passed into
    the wrapped code in place of the Database. After the function is
    complete, the newly created transaction will be committed.

    It is important to note that the wrapped method may be called
    multiple times in the event of a commit failure, until the commit
    succeeds.

    If given a Transaction, the Transaction will be passed into the
    wrapped code, and WILL NOT be committed at completion of the
    function. This allows new transactional functions to be composed
    of other transactional methods.

    The transactional decorator may be used with or without
    arguments. The keyword argument 'parameter' is recognized and
    specifies the name of the parameter to the wrapped function that
    will contain either a Database or Transaction.

    """
    def decorate(func):
        try:
            parameter = tr_kwargs['parameter']
        except:
            parameter = 'tr'

        index = inspect.getargspec(func).args.index(parameter)

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if isinstance(args[index], Transaction):
                return func(*args, **kwargs)

            largs = list(args)
            tr = largs[index] = args[index].create_transaction()

            committed = False
            warned = False
            retries = 0
            start = datetime.datetime.now()
            last = start

            while not committed:
                try:
                    ret = func(*largs, **kwargs)
                    tr.commit().wait()
                    committed = True
                except FDBError as e:
                    tr.on_error(e.code).wait()

                now = datetime.datetime.now()
                td = now - last
                elapsed = (td.microseconds + (td.seconds + td.days * 24 * 3600) * 10**6) / float(10**6)
                if elapsed >= 1:
                    # SOMEDAY: it would be nice to provide more
                    # information than just the undecorated
                    # function name, but that doesn't seem to be
                    # non-trivial
                    td = now - start
                    secs = (td.microseconds + (td.seconds + td.days * 24 * 3600) * 10**6) / float(10**6)
                    print ('fdb WARNING: long transaction (%gs elapsed in transactional function \'%s\' (%d retries, %s))' % (elapsed, func.__name__, retries, committed and 'committed' or 'not yet committed'))
                    last = now

                retries += 1

            return ret

        return wrapper

    if not tr_args:
        # Being called with parameters (possibly none); return a
        # decorator
        return decorate
    elif len(tr_args) == 1 and not tr_kwargs:
        # Being called as a decorator
        return decorate(tr_args[0])
    else:
        raise Exception('Invalid use of transactional decorator.')
        
class FDBError(Exception):
    """This exception is raised when an FDB API call returns an
    error. The error code will be stored in the code attribute, and a
    textual description of the error will be stored in the description
    attribute.

    """
    def __init__(self, code, description):
        self.code = code

        self.description = description

    def __str__(self):
        return '%s (%d)' % (self.description, self.code)


class _FDBBase(object):
    # By inheriting from _FDBBase, every class gets access to self.capi
    # (set below when we open libfdb_capi)
    pass


class FDBRange(object):
    """Iterates over the results of an FDB range query. Returns
    KeyValue objects.

    """

    def __init__(self, tr, begin, end, limit, reverse, streaming_mode):
        self._tr = tr

        self._bsel = begin
        self._esel = end

        self._limit = limit
        self._reverse = reverse
        self._mode = streaming_mode

    def to_list(self):
        return [x for x in self.__iter__(mode=StreamingMode.want_all)]

    def __iter__(self, mode=None):
        if mode is None:
            mode = self._mode
        bsel = self._bsel
        esel = self._esel
        limit = self._limit

        iteration = 1
        future = self._tr._get_range(bsel, esel, limit, mode, iteration, self._reverse)

        done = False

        while not done:
            if future:
                (kvs, count, more) = future.wait()
                index = 0
                future = None

                if not count:
                    return

            result = kvs[index]
            index += 1

            if index == count:
                if not more or limit == count:
                    done = True
                else:
                    iteration += 1
                    if limit > 0:
                        limit = limit - count
                    if self._reverse:
                        esel = KeySelector.first_greater_or_equal(kvs[-1].key)
                    else:
                        bsel = KeySelector.first_greater_than(kvs[-1].key)
                    future = self._tr._get_range(bsel, esel, limit, mode, iteration, self._reverse)

            yield result


class TransactionRead(_FDBBase):
    def __init__(self, tpointer, db, snapshot):
        self.tpointer = tpointer
        self.db = db
        self._snapshot = snapshot

    def __del__(self):
        # print 'Destroying transactionread 0x%x' % self.tpointer
        self.capi.fdb_transaction_destroy(self.tpointer)

    def get_read_version(self):
        """Get the read version of the transaction."""
        return FutureVersion(self.capi.fdb_transaction_get_read_version(self.tpointer))

    def get(self, key):
        if isinstance(key, FutureString):
            key = key.value
        return Value(self.capi.fdb_transaction_get(self.tpointer, key, len(key), self._snapshot))

    def get_key(self, key_selector):
        return Key(self.capi.fdb_transaction_get_key(
            self.tpointer, key_selector.key, len(key_selector.key), key_selector.or_equal, key_selector.offset, self._snapshot))

    def _get_range(self, begin, end, limit, streaming_mode, iteration, reverse):
        return FutureKeyValueArray(
            self.capi.fdb_transaction_get_range(
                self.tpointer, begin.key, len(begin.key), begin.or_equal, begin.offset,
                end.key, len(end.key), end.or_equal, end.offset,
                limit, 0, streaming_mode, iteration, self._snapshot, reverse))

    def _to_selector(self, key_or_selector):
        if not isinstance(key_or_selector, KeySelector):
            if isinstance(key_or_selector, FutureString): 
                key_or_selector = key_or_selector.value
            key_or_selector = KeySelector.first_greater_or_equal(key_or_selector)
        return key_or_selector
                
    def get_range(self, begin, end, limit=0, reverse=False, streaming_mode=StreamingMode.iterator):
        if begin is None: begin = b''
        if end is None: end = b'\xff'
        begin = self._to_selector(begin)
        end = self._to_selector(end)
        return FDBRange(self, begin, end, limit, reverse, streaming_mode)

    def get_range_startswith(self, prefix, *args, **kwargs):
        return self.get_range(prefix, strinc(prefix), *args, **kwargs)

    def __getitem__(self, key):
        if isinstance(key, slice):
            return self.get_range(key.start, key.stop, reverse=(key.step == -1))
        return self.get(key)

class Transaction(TransactionRead):
    """A modifiable snapshot of a Database.

    """

    def __init__(self, tpointer, db):
        super(Transaction, self).__init__(tpointer, db, False)
        self.options = _TransactionOptions(self)
        self.__snapshot = self.snapshot = TransactionRead(tpointer, db, True)

    def __del__(self):
        pass

    def set_read_version(self, version):
        """Set the read version of the transaction."""
        self.capi.fdb_transaction_set_read_version(self.tpointer, version)

    def _set_option(self, option, param=None):
        self.capi.fdb_transaction_set_option(self.tpointer, option, param, param and len(param) or 0)

    def set(self, key, value):
        if isinstance(key, FutureString):
            key = key.value
        if isinstance(value, FutureString):
            value = value.value
        self.capi.fdb_transaction_set(self.tpointer, key, len(key), value, len(value))

    def clear(self, key):
        if isinstance(key, KeySelector):
            key = self.get_key(key)
        if isinstance(key, FutureString):
            key = key.value
        self.capi.fdb_transaction_clear(self.tpointer, key, len(key))

    def clear_range(self, begin, end):
        if begin is None: begin = b''
        if end is None: end = b'\xff'
        if isinstance(begin, KeySelector):
            begin = self.get_key(begin)
        if isinstance(end, KeySelector):
            end = self.get_key(end)
        if isinstance(begin, FutureString):
            begin = begin.value
        if isinstance(end, FutureString):
            end = end.value
        self.capi.fdb_transaction_clear_range(self.tpointer, begin, len(begin),
                                              end, len(end))

    def clear_range_startswith(self, prefix):
        if isinstance(prefix, FutureString):
            prefix = prefix.value
        return self.clear_range(prefix, strinc(prefix))

    def commit(self):
        return FutureVoid(self.capi.fdb_transaction_commit(self.tpointer))

    def get_committed_version(self):
        version = ctypes.c_int64()
        self.capi.fdb_transaction_get_committed_version(self.tpointer, ctypes.byref(version))
        return version.value

    def on_error(self, error):
        if isinstance(error, FDBError):
            code = error.code
        elif isinstance(error, (int, long)):
            code = error
        else:
            raise error
        return FutureVoid(self.capi.fdb_transaction_on_error(self.tpointer, code))

    def reset(self):
        self.capi.fdb_transaction_reset(self.tpointer)

    def __setitem__(self, key, value):
        self.set(key, value)

    def __delitem__(self, key):
        if isinstance(key, slice):
            self.clear_range( key.start, key.stop )
        else:
            self.clear(key)

class Future(_FDBBase):
    Event = threading.Event

    def __init__(self, fpointer):
        #print 'Creating future 0x%x' % fpointer
        self.fpointer = fpointer
        self.callbacks = []
        self.cb = None
        self.cb_sem = threading.Semaphore()

    def __del__(self):
        if self.fpointer:
            #print 'Destroying future 0x%x' % self.fpointer
            self.capi.fdb_future_destroy(self.fpointer)
            self.fpointer = None

    def wait(self):
        raise NotImplementedError

    def is_ready(self):
        return not self.fpointer or bool( self.capi.fdb_future_is_ready(self.fpointer) )

    def block_until_ready(self):
        if not self.fpointer: return
        self.capi.fdb_future_block_until_ready(self.fpointer)

    def on_ready(self, callback):
        if not self.fpointer:
            callback(self)

        self.cb_sem.acquire()
        self.callbacks.append(callback)

        if self.cb:
            self.cb_sem.release()
            return

        def cb_and_delref(ignore):
            ctypes.pythonapi.Py_DecRef(ctypes.py_object(self))

            i = 0
            while True:
                if i < len(self.callbacks):
                    self.callbacks[i](self)
                    i += 1
                else:
                    self.cb_sem.acquire()
                    if len(self.callbacks) != i:
                        self.cb_sem.release()
                    else:
                        self.callbacks = []
                        self.cb = None
                        self.cb_sem.release()
                        break

        self.cb = _CBFUNC(cb_and_delref)
        self.cb_sem.release()
        ctypes.pythonapi.Py_IncRef(ctypes.py_object(self))
        self.capi.fdb_future_set_callback(self.fpointer, self.cb, None)


class FutureVoid(Future):
    def wait(self):
        self.block_until_ready()
        if self.capi.fdb_future_is_error(self.fpointer):
            self.capi.fdb_future_get_error(self.fpointer, None)
        return None


class FutureVersion(Future):
    def wait(self):
        self.block_until_ready()
        version = ctypes.c_int64()
        self.capi.fdb_future_get_version(self.fpointer, ctypes.byref(version))
        return version.value


class FutureKeyValueArray(Future):
    def wait(self):
        self.block_until_ready()
        kvs = ctypes.pointer(KeyValueStruct())
        count = ctypes.c_int()
        more = ctypes.c_int()
        self.capi.fdb_future_get_keyvalue_array(self.fpointer, ctypes.byref(kvs), ctypes.byref(count), ctypes.byref(more))
        return ([KeyValue(ctypes.string_at(x.key, x.key_length), ctypes.string_at(x.value, x.value_length)) for x in kvs[0:count.value]], count.value, more.value)


class LazyFuture(Future):
    def __init__(self, *args, **kwargs):
        super(LazyFuture, self).__init__(*args, **kwargs)
        self._error = None
        self._set = False

    def wait(self):
        if self.fpointer:
            self.block_until_ready()
            if self.capi.fdb_future_is_error(self.fpointer):
                self.capi.fdb_future_get_error(self.fpointer, None)
        return self

    def _lazy_property(self, attr):
        if not self._set:
            # ev = self.Event()
            # def get_cb(self):
            #     if self.fpointer:
            #         try:
            #             self._getter()
            #         except FDBError as e:
            #             self._error = e
            #             # Must NOT raise the exception in the
            #             # callback, as the event would never be set,
            #             # and the main interpreter thread would
            #             # continue to block.
            #         finally:
            #             Future.__del__(self)
            #             self._set = True
            #     ev.set()
            # self.on_ready(get_cb)
            # ev.wait()
            try:
                self.block_until_ready()
                self._getter()
            except FDBError as e:
                self._error = e
            finally:
                Future.__del__(self)
                self._set = True
        if self._error:
            raise self._error
        return getattr(self, attr)


class FutureString(LazyFuture):
    def __init__(self, *args):
        self._error = None
        self._value = None
        super(FutureString, self).__init__(*args)

    def getclass(self):
        return str
    __class__ = property(getclass)

    def _getter(self):
        raise NotImplementedError

    @property
    def value(self):
        return self._lazy_property('_value')

    def __str__(self):
        return self.value.__str__()

    def __repr__(self):
        return self.value.__repr__()

    def __add__(self, rhs):
        if isinstance(rhs, FutureString):
            rhs = rhs.value
        return self.value + rhs

    def __radd__(self, lhs):
        if isinstance(lhs, FutureString):
            lhs = lhs.value
        return lhs + self.value

    def __mul__(self, rhs):
        return self.value * rhs

    def __rmul__(self, lhs):
        return lhs * self.value

    def __lt__(self, rhs):
        if isinstance(rhs, FutureString):
            rhs = rhs.value
        return self.value < rhs

    def __le__(self, rhs):
        if isinstance(rhs, FutureString):
            rhs = rhs.value
        return self.value <= rhs

    def __gt__(self, rhs):
        if isinstance(rhs, FutureString):
            rhs = rhs.value
        return self.value > rhs

    def __ge__(self, rhs):
        if isinstance(rhs, FutureString):
            rhs = rhs.value
        return self.value >= rhs

    def __eq__(self, rhs):
        if isinstance(rhs, FutureString):
            rhs = rhs.value
        return self.value == rhs

    def __ne__(self, rhs):
        return not self == rhs

    def __nonzero__(self):
        return bool(self.value)

    def __int__(self):
        return int(self.value)

def makewrapper(func):
    def tmpfunc(self, *args):
        return func(self.value, *args)
    return tmpfunc

for i in dir(bytes):
    if not i.startswith('_') or i in ('__getitem__','__getslice__','__hash__', '__len__'):
        setattr(FutureString, i, makewrapper(getattr(bytes, i)))


class Value(FutureString):
    def _getter(self):
        present = ctypes.c_int()
        value = ctypes.pointer(ctypes.c_byte())
        value_length = ctypes.c_int()
        self.capi.fdb_future_get_value(self.fpointer, ctypes.byref(present),
                                       ctypes.byref(value), ctypes.byref(value_length))
        if present.value:
            self._value = ctypes.string_at(value, value_length.value)

    def present(self):
        return self.value is not None


class Key(FutureString):
    def _getter(self):
        key = ctypes.pointer(ctypes.c_byte())
        key_length = ctypes.c_int()
        self.capi.fdb_future_get_key(self.fpointer, ctypes.byref(key), ctypes.byref(key_length))
        self._value = ctypes.string_at(key, key_length.value)


class Database(LazyFuture):
    def __init__(self, *args, **kwargs):
        super(Database, self).__init__(*args, **kwargs)
        self._dpointer = None
        self.options = _DatabaseOptions(self)

    def _getter(self):
        database = ctypes.c_void_p()
        self.capi.fdb_future_get_database(self.fpointer, ctypes.byref(database))
        self._dpointer = database.value

    @property
    def dpointer(self):
        return self._lazy_property('_dpointer')

    def __del__(self):
        if self._dpointer:
            # print 'Destroying database 0x%x' % self._dpointer
            self.capi.fdb_database_destroy(self._dpointer)
        super(self.__class__, self).__del__()

    @staticmethod
    @transactional
    def __database_getitem(tr, key):
        return tr[key]

    def get(self, key):
        return Database.__database_getitem(self, key)

    def __getitem__(self, key):
        if isinstance(key, slice):
            return self.get_range(key.start, key.stop, reverse=(key.step==-1))
        return Database.__database_getitem(self, key)

    @staticmethod
    @transactional
    def __database_get_key(tr, key_selector):
        return tr.get_key(key_selector)

    def get_key(self, key_selector):
        return Database.__database_get_key(self, key_selector)

    @staticmethod
    @transactional
    def __database_get_range(tr, begin, end, limit, reverse, streaming_mode):
        return tr.get_range(begin, end, limit, reverse, streaming_mode).to_list()

    def get_range(self, begin, end, limit=0, reverse=False, streaming_mode=StreamingMode.want_all):
        return Database.__database_get_range(self, begin, end, limit, reverse, streaming_mode)

    @staticmethod
    @transactional
    def __database_get_range_startswith(tr, prefix, *args, **kwargs):
        return tr.get_range_startswith(prefix, *args, **kwargs).to_list()

    def get_range_startswith(self, prefix, *args, **kwargs):
        return Database.__database_get_range_startswith(self, prefix, *args, **kwargs)

    @staticmethod
    @transactional
    def __database_setitem(tr, key, value):
        tr[key] = value

    def set(self, key, value):
        Database.__database_setitem(self, key, value)

    def __setitem__(self, key, value):
        Database.__database_setitem(self, key, value)

    @staticmethod
    @transactional
    def __database_delitem(tr, key_or_slice):
        del tr[key_or_slice]
        
    def __delitem__(self, key_or_slice):
        Database.__database_delitem(self, key_or_slice)

    @staticmethod
    @transactional
    def __database_clear_range_startswith(tr, prefix):
        tr.clear_range_startswith(prefix)

    def clear_range_startswith(self, prefix):
        Database.__database_clear_range_startswith(self, prefix)
        
    def create_transaction(self):
        pointer = ctypes.c_void_p()
        self.capi.fdb_database_create_transaction(self.dpointer, ctypes.byref(pointer))
        return Transaction(pointer.value, self)

    def _set_option(self, option, param=None):
        self.capi.fdb_database_set_option(self.dpointer, option, param, param and len(param) or 0)


class Cluster(LazyFuture):
    def __init__(self, *args):
        super(Cluster, self).__init__(*args)
        self._cpointer = None
        self._error = None
        self.options = _ClusterOptions(self)

    def _getter(self):
        cluster = ctypes.c_void_p()
        self.capi.fdb_future_get_cluster(self.fpointer, ctypes.byref(cluster))
        self._cpointer = cluster.value

    @property
    def cpointer(self):
        return self._lazy_property('_cpointer')

    def __del__(self):
        if self._cpointer:
            # print 'Destroying cluster 0x%x' % self._cpointer
            self.capi.fdb_cluster_destroy(self._cpointer)
        super(self.__class__, self).__del__()

    def open_database(self, name):
        return Database(self.capi.fdb_cluster_create_database(self.cpointer, name, len(name)))

    def _set_option(self, option, param=None):
        self.capi.fdb_cluster_set_option(self.cpointer, option, param, param and len(param) or 0)


def create_cluster(cluster_file):
    return Cluster(_capi.fdb_create_cluster(cluster_file))


class KeySelector(object):
    def __init__(self, key, or_equal, offset):
        self.key = key
        self.or_equal = or_equal
        self.offset = offset

    def __add__(self, offset):
        return KeySelector(self.key, self.or_equal, self.offset+offset)

    def __sub__(self, offset):
        return KeySelector(self.key, self.or_equal, self.offset-offset)

    @classmethod
    def last_less_than(cls, key):
        return cls(key, False, 0)

    @classmethod
    def last_less_or_equal(cls, key):
        return cls(key, True, 0)

    @classmethod
    def first_greater_than(cls, key):
        return cls(key, True, 1)

    @classmethod
    def first_greater_or_equal(cls, key):
        return cls(key, False, 1)

    def __str__(self):
        return 'KeySelector(%s, %r, %d)' % (self.key, self.or_equal, self.offset)


class KVIter(object):
    def __init__(self, obj):
        self.obj = obj
        self.index = 0

    def __iter__(self):
        return self

    def next(self):
        self.index += 1
        if self.index == 1:
            return self.obj.key
        elif self.index == 2:
            return self.obj.value
        else:
            raise StopIteration


class KeyValueStruct(ctypes.Structure):
    _fields_ = [('key', ctypes.POINTER(ctypes.c_byte)),
                ('key_length', ctypes.c_int),
                ('value', ctypes.POINTER(ctypes.c_byte)),
                ('value_length', ctypes.c_int)]
    _pack_ = 4


class KeyValue(object):
    def __init__(self, key, value):
        self.key = key
        self.value = value

    def __repr__(self):
        return '%s: %s' % (self.key, self.value)

    def __iter__(self):
        return KVIter(self)


def check_error_code(code, func, arguments):
    if code:
        raise FDBError(code, _capi.fdb_get_error(code))
    return None

import platform, os, sys
if sys.maxsize <= 2**32:
    raise Exception("FoundationDB API requires a 64-bit python interpreter!")
if platform.system() == 'Windows':
    capi_name = 'fdb_c.dll'
else:
    capi_name = 'libfdb_c.so'
this_dir = os.path.dirname(__file__)

# Preferred installation: The C API library or a symbolic link to the
#    library should be in the same directory as this module.
# Failing that, a file named $(capi_name).pth should be in the same directory,
#    and a relative path to the library (including filename)
def read_pth_file():
    pth_file = os.path.join(this_dir, capi_name+'.pth')
    if not os.path.exists(pth_file): return None
    pth = _open_file(pth_file, "rt").read().strip()
    if pth[0]!='/': pth = os.path.join(this_dir, pth)
    return pth

for pth in [
        lambda: os.path.join(this_dir, capi_name),
        #lambda: os.path.join(this_dir, '../../lib', capi_name),  # For compatibility with existing unix installation process... should be removed
        read_pth_file
    ]:
    p = pth()
    if p and os.path.exists(p):
        _capi = ctypes.CDLL(os.path.abspath(p))
        break
else:
    raise Exception( "Unable to locate the FoundationDB API shared library!" )

class CByteP (object):
    def from_param(self, param):
        return ctypes.c_void_p.from_param(bytes(param))
ctypes.c_byte_p = CByteP()

_FDBBase.capi = _capi

_capi.fdb_select_api_version_impl.argtypes = [ctypes.c_int, ctypes.c_int]
_capi.fdb_select_api_version_impl.restype = ctypes.c_int
_capi.fdb_select_api_version_impl.errcheck = check_error_code

_capi.fdb_get_error.argtypes = [ctypes.c_int]
_capi.fdb_get_error.restype = ctypes.c_char_p

_capi.fdb_setup_network.argtypes = []
_capi.fdb_setup_network.restype = ctypes.c_int
_capi.fdb_setup_network.errcheck = check_error_code

_capi.fdb_network_set_option.argtypes = [ctypes.c_int, ctypes.c_byte_p, ctypes.c_int]
_capi.fdb_network_set_option.restype = ctypes.c_int
_capi.fdb_network_set_option.errcheck = check_error_code

_capi.fdb_run_network.argtypes = []
_capi.fdb_run_network.restype = ctypes.c_int
_capi.fdb_run_network.errcheck = check_error_code

_capi.fdb_stop_network.argtypes = []
_capi.fdb_stop_network.restype = ctypes.c_int
_capi.fdb_stop_network.errcheck = check_error_code

_capi.fdb_future_destroy.argtypes = [ctypes.c_void_p]
_capi.fdb_future_destroy.restype = None

_capi.fdb_future_block_until_ready.argtypes = [ctypes.c_void_p]
_capi.fdb_future_block_until_ready.restype = ctypes.c_int
_capi.fdb_future_block_until_ready.errcheck = check_error_code

_capi.fdb_future_is_ready.argtypes = [ctypes.c_void_p]
_capi.fdb_future_is_ready.restype = ctypes.c_int

_capi.fdb_future_is_error.argtypes = [ctypes.c_void_p]
_capi.fdb_future_is_error.restype = ctypes.c_int

_CBFUNC = ctypes.CFUNCTYPE(None, ctypes.c_void_p)

_capi.fdb_future_set_callback.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
_capi.fdb_future_set_callback.restype = int
_capi.fdb_future_set_callback.errcheck = check_error_code

_capi.fdb_future_get_error.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
_capi.fdb_future_get_error.restype = int
_capi.fdb_future_get_error.errcheck = check_error_code

_capi.fdb_future_get_version.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int64)]
_capi.fdb_future_get_version.restype = ctypes.c_int
_capi.fdb_future_get_version.errcheck = check_error_code

_capi.fdb_future_get_key.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.POINTER(ctypes.c_byte)),
                                        ctypes.POINTER(ctypes.c_int)]
_capi.fdb_future_get_key.restype = ctypes.c_int
_capi.fdb_future_get_key.errcheck = check_error_code

_capi.fdb_future_get_cluster.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
_capi.fdb_future_get_cluster.restype = ctypes.c_int
_capi.fdb_future_get_cluster.errcheck = check_error_code

_capi.fdb_future_get_database.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
_capi.fdb_future_get_database.restype = ctypes.c_int
_capi.fdb_future_get_database.errcheck = check_error_code

_capi.fdb_future_get_value.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int),
                                          ctypes.POINTER(ctypes.POINTER(ctypes.c_byte)), ctypes.POINTER(ctypes.c_int)]
_capi.fdb_future_get_value.restype = ctypes.c_int
_capi.fdb_future_get_value.errcheck = check_error_code

_capi.fdb_future_get_keyvalue_array.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.POINTER(KeyValueStruct)), ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)]
_capi.fdb_future_get_keyvalue_array.restype = int
_capi.fdb_future_get_keyvalue_array.errcheck = check_error_code

_capi.fdb_create_cluster.argtypes = [ctypes.c_char_p]
_capi.fdb_create_cluster.restype = ctypes.c_void_p

_capi.fdb_cluster_destroy.argtypes = [ctypes.c_void_p]
_capi.fdb_cluster_destroy.restype = None

_capi.fdb_cluster_create_database.argtypes = [ctypes.c_void_p, ctypes.c_byte_p, ctypes.c_int]
_capi.fdb_cluster_create_database.restype = ctypes.c_void_p

_capi.fdb_cluster_set_option.argtypes = [ctypes.c_int, ctypes.c_byte_p, ctypes.c_int]
_capi.fdb_cluster_set_option.restype = ctypes.c_int
_capi.fdb_cluster_set_option.errcheck = check_error_code

_capi.fdb_database_destroy.argtypes = [ctypes.c_void_p]
_capi.fdb_database_destroy.restype = None

_capi.fdb_database_create_transaction.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
_capi.fdb_database_create_transaction.restype = ctypes.c_int
_capi.fdb_database_create_transaction.errcheck = check_error_code

_capi.fdb_database_set_option.argtypes = [ctypes.c_int, ctypes.c_byte_p, ctypes.c_int]
_capi.fdb_database_set_option.restype = ctypes.c_int
_capi.fdb_database_set_option.errcheck = check_error_code

_capi.fdb_transaction_destroy.argtypes = [ctypes.c_void_p]
_capi.fdb_transaction_destroy.restype = None

_capi.fdb_transaction_set_read_version.argtypes = [ctypes.c_void_p, ctypes.c_int64]
_capi.fdb_transaction_set_read_version.restype = None

_capi.fdb_transaction_get_read_version.argtypes = [ctypes.c_void_p]
_capi.fdb_transaction_get_read_version.restype = ctypes.c_void_p

_capi.fdb_transaction_get.argtypes = [ctypes.c_void_p, ctypes.c_byte_p, ctypes.c_int, ctypes.c_int]
_capi.fdb_transaction_get.restype = ctypes.c_void_p

_capi.fdb_transaction_get_key.argtypes = [ctypes.c_void_p, ctypes.c_byte_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]
_capi.fdb_transaction_get_key.restype = ctypes.c_void_p

_capi.fdb_transaction_get_range.argtypes = [ctypes.c_void_p, ctypes.c_byte_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_byte_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]
_capi.fdb_transaction_get_range.restype = ctypes.c_void_p

_capi.fdb_transaction_set_option.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_byte_p, ctypes.c_int]
_capi.fdb_transaction_set_option.restype = ctypes.c_int
_capi.fdb_transaction_set_option.errcheck = check_error_code

_capi.fdb_transaction_set.argtypes = [ctypes.c_void_p, ctypes.c_byte_p, ctypes.c_int, ctypes.c_byte_p, ctypes.c_int]
_capi.fdb_transaction_set.restype = None

_capi.fdb_transaction_clear.argtypes = [ctypes.c_void_p, ctypes.c_byte_p, ctypes.c_int]
_capi.fdb_transaction_clear.restype = None

_capi.fdb_transaction_clear_range.argtypes = [ctypes.c_void_p, ctypes.c_byte_p, ctypes.c_int, ctypes.c_byte_p, ctypes.c_int]
_capi.fdb_transaction_clear_range.restype = None

_capi.fdb_transaction_commit.argtypes = [ctypes.c_void_p]
_capi.fdb_transaction_commit.restype = ctypes.c_void_p

_capi.fdb_transaction_get_committed_version.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int64)]
_capi.fdb_transaction_get_committed_version.restype = ctypes.c_int
_capi.fdb_transaction_get_committed_version.errcheck = check_error_code

_capi.fdb_transaction_on_error.argtypes = [ctypes.c_void_p, ctypes.c_int]
_capi.fdb_transaction_on_error.restype = ctypes.c_void_p

_capi.fdb_transaction_reset.argtypes = [ctypes.c_void_p]
_capi.fdb_transaction_reset.restype = None

def init(event_model=None):
    """Initialize the FDB interface.
    
    Consider using open() as a higher-level interface.

    By default looks for a fdb.cluster file in platform-specific locations to
    determine an appropriate network interface.  Use options.set_cluster_file or
    options.set_local_address to change this behavior. 

    Keyword arguments:
    event_model -- the event model to support (default None, also 'gevent')

    """
    if event_model is not None:
        if event_model == 'gevent':
            import gevent
            import gevent.socket

            import os

            class ThreadEvent(object):
                def __init__(self):
                    self.pair = os.pipe()

                def set(self):
                    os.write(self.pair[1], '!')

                def wait(self):
                    gevent.socket.wait_read(self.pair[0])

                def __del__(self):
                    os.close(self.pair[0])
                    os.close(self.pair[1])

            Future.Event = ThreadEvent

            def _gevent_block_until_ready(self):
                if self.is_ready():
                    return
                e = self.Event()
                def is_ready_cb(future):
                    e.set()
                self.on_ready(is_ready_cb)
                e.wait()

            Future.block_until_ready = _gevent_block_until_ready
        elif event_model == 'debug':
            import time

            class DebugEvent(object):
                def __init__(self):
                    self.ev = threading.Event()
                def set(self):
                    self.ev.set()
                def wait(self):
                    while not self.ev.isSet():
                        self.ev.wait(.001)
            Future.Event = DebugEvent
            
            def _debug_block_until_ready(self):
                while not self.is_ready():
                    time.sleep(.001)
            Future.block_until_ready = _debug_block_until_ready
        else:
            # Hard coded error
            raise FDBError(2000, 'The client made an invalid API call')

    _capi.fdb_setup_network()

    class NetworkThread(threading.Thread):
        def run(self):
            _capi.fdb_run_network()
            # print 'Network stopped'

    global _network_thread
    _network_thread = NetworkThread()
    _network_thread.daemon = True

    _network_thread.start()
    # print 'Network started'

def init_v13(local_address, event_model=None):
    options.set_local_address(local_address)
    init(event_model)

open_clusters = {}
open_databases = {}
def open( cluster_file = None, database_name = "DB", event_model = None ):
    """Opens the given database (or the default database of the cluster indicated
    by the fdb.cluster file in a platform-specific location, if no cluster_file
    or database_name is provided).  Initializes the FDB interface as required."""
    global _network_thread
    if not _network_thread:
       if cluster_file:
           options.set_cluster_file(cluster_file)
       init(event_model = event_model)
    if not cluster_file in open_clusters:
        open_clusters[cluster_file] = create_cluster( cluster_file )
    if not (cluster_file, database_name) in open_databases:
        open_databases[(cluster_file, database_name)] = open_clusters[cluster_file].open_database(database_name)
    return open_databases[(cluster_file, database_name)]

def open_v13( cluster_id_path, database_name, local_address=None, event_model = None ):
    global _network_thread
    if not _network_thread:
        if local_address:
            options.set_local_address( local_address )
        else:
            options.set_cluster_file( cluster_id_path )
        init( event_model = event_model )
    return open( cluster_id_path, database_name )

import atexit

@atexit.register
def _stop_on_exit():
    if _network_thread:
        _capi.fdb_stop_network()
        _network_thread.join()

def strinc(key):
    lastc = (ord(key[-1:]) + 1) % 256
    if lastc:
        return key[:-1] + chr(lastc)
    else:
        return strinc(key[:-1]) + chr(lastc)        

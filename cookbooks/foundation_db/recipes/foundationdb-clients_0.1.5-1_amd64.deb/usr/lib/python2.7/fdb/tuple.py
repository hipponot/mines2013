# FoundationDB Python API
# Copyright 2009-2012 FoundationDB, LLC. All Rights Reserved.
#
# This is a confidential non-public alpha version of FoundationDB's
# software. Participation in this alpha testing program is by
# invitation only and the possession, use, and replication of the
# FoundationDB software is subject to the FoundationDB Alpha Software 
# Evaluation License Agreement, which can be found at
# http://foundationdb.com/AlphaLicenseAgreement.pdf

import struct
from bisect import bisect_left

_size_limits = tuple( (1 << (i*8))-1 for i in range(9) )

def _find_terminator( v, pos ):
    # Finds the start of the next terminator [\x00]![\xff] or the end of v
    while True:
        pos = v.find('\x00', pos)
        if pos<0:
            return len(v)
        if pos+1==len(v) or v[pos+1] != '\xff':
            return pos
        pos += 2
        
def _decode(v, pos):
    code = ord(v[pos])
    if code == 0:
        return None, pos+1
    elif code == 1:
        end = _find_terminator(v, pos+1)
        return v[pos+1:end].replace("\x00\xFF", "\x00"), end+1
    elif code == 2:
        end = _find_terminator(v, pos+1)
        return v[pos+1:end].replace("\x00\xFF", "\x00").decode("utf-8"), end+1
    elif code >= 20 and code <= 28:
        n = code - 20
        end = pos + 1 + n
        return struct.unpack(">Q", chr(0)*(8-n) + v[pos+1:end])[0], end
    elif code >= 12 and code < 20:
        n = 20 - code
        end = pos + 1 + n
        return struct.unpack(">Q", chr(0)*(8-n) + v[pos+1:end])[0]-_size_limits[n], end
    else:
        raise ValueError("Unknown data type in DB: " + repr(v))

def _encode(value):
    # returns [code][data] (code != 0xFF)
    # encoded values are self-terminating
    # sorting need to work too!
    if value==None:
        return chr(0)
    elif isinstance(value, str):
        return chr(1) + value.replace('\x00', '\x00\xFF') + '\x00'
    elif isinstance(value, unicode):
        return chr(2) + value.encode('utf-8').replace('\x00', '\x00\xFF') + '\x00'
    elif isinstance(value, (int, long)):
        if value == 0:
            return chr(20)
        elif value > 0:
            n = bisect_left( _size_limits, value )
            return chr(20 + n) + struct.pack( ">Q", value )[-n:]
        else:
            n = bisect_left( _size_limits, -value )
            maxv = _size_limits[n]
            return chr(20 - n) + struct.pack( ">Q", maxv+value)[-n:]
    else:
        raise ValueError("Unsupported data type: " + str(type(value)))


# packs the specified tuple into a key
def pack(t):
    if not isinstance(t, tuple):
        raise Exception("fdbtuple pack() expects a tuple, got a " + str(type(t)))
    return ''.join([_encode(x) for x in t])

# unpacks the specified key into a tuple
def unpack(key):
    pos = 0
    res = []
    while pos < len(key):
        r, pos = _decode(key, pos)
        res.append(r)
    return tuple(res)

_range = range
def range(t):
    """Returns a slice of keys that includes all tuples of greater
    length than the specified tuple that that start with the
    specified elements.

    e.g. range(('a', 'b')) includes all tuples ('a', 'b', ...)"""

    if not isinstance(t, tuple):
        raise Exception("fdbtuple range() expects a tuple, got a " + str(type(t)))

    p = pack(t)
    return slice(
        p+'\x00', 
        p+'\xff')

import random
def randomElement():
    r = random.randint(0,3)
    if r==0:
        chars = ['\x00', '\x01', 'a', '7', '\xfe', '\ff']
        return ''.join([random.choice(chars) for c in _range(random.randint(0, 5))])
    elif r==1:
        chars = [u'\x00', u'\x01', u'a', u'7', u'\xfe', u'\ff', u'\u0000', u'\u0001', u'\uffff', u'\uff00']
        return u''.join([random.choice(chars) for c in _range(random.randint(0, 5))])
    elif r==2:
        return random.choice([-1, 1]) * 2**random.randint(0, 62) + random.randint(-10, 10)
    elif r==3:
        return None

def randomTuple():
    return tuple( randomElement() for x in _range(random.randint(0,4)) )

def isprefix(a,b):
    return tupleorder(a) == tupleorder(b[:len(a)])

def torder(x):
    if x == None:
        return 0
    elif isinstance(x,str):
        return 1
    elif isinstance(x,unicode):
        return 2
    elif isinstance(x, (int,long)):
        return 3
    raise Exception("Unknown type")
def tupleorder(t):
    return tuple( (torder(e),e) for e in t )

def tupleTest(N=1000):
    global someTuples, a, b
    someTuples = [ randomTuple() for i in _range(N) ]
    a = sorted(someTuples, key=lambda t:tupleorder(t))
    b = sorted(someTuples, key=lambda t:pack(t))
    assert a == b

    print "Sort OK"
    
    for i in _range(N):
        t = randomTuple()
        t2 = t + (randomElement(),)
        t3 = randomTuple()
        try:
            assert(unpack(pack(t)) == t)
            
            r = range(t)
            assert not (r.start <= pack(t) < r.stop)
            assert (r.start <= pack(t2) < r.stop)

            if not isprefix(t, t3):
                assert not (r.start <= pack(t3) <= r.stop)

            assert (tupleorder(t) < tupleorder(t3)) == (pack(t) < pack(t3))
        except:
            print repr(t), repr(t2), repr(t3)
            raise
    
# test:
# a = ('\x00a', -2, 'b\x01', 12345, '')
# assert(a==fdbtuple.unpack(fdbtuple.pack(a)))

NetworkOption = {
    "LOCAL_ADDRESS" : (10, "IP:PORT", "The address to which the client should bind. Either LOCAL_ADDRESS or FDB_CLUSTER_FILE should be specified, but not both."),
    "CLUSTER_FILE" : (20, "path to cluster file", "Sets the cluster file to parse so a network interface can be chosen for the client. This file is not used to connect to a cluster. Either LOCAL_ADDRESS or FDB_CLUSTER_FILE should be specified, but not both."),
    "TRACE_ENABLE" : (30, "path to output directory (or NULL for current working directory)", "Enables trace output to a file in a directory of the clients choosing"),
}

ClusterOption = {

}

DatabaseOption = {

}

TransactionOption = {
    "CAUSAL_WRITE_RISKY" : (10, None, "The transaction, if not self-conflicting, may be committed a second time after commit succeeds, in the event of a fault"),
    "CAUSAL_READ_RISKY" : (20, None, "The read version will be committed, and usually will be the latest committed, but might not be the latest committed in the event of a fault or partition"),
    "CAUSAL_READ_DISABLE" : (21, None, ""),
    "CHECK_WRITES_ENABLE" : (50, None, ""),
    "READ_YOUR_WRITES_DISABLE" : (51, None, ""),
    "READ_AHEAD_DISABLE" : (52, None, ""),
    "DURABILITY_DATACENTER" : (110, None, ""),
    "DURABILITY_RISKY" : (120, None, ""),
    "DURABILITY_DEV_NULL_IS_WEB_SCALE" : (130, None, ""),
    "PRIORITY_SYSTEM_IMMEDIATE" : (200, None, "Specifies that this transaction should be treated as highest priority and that lower priority transactions should block behind this one. Use is discouraged outside of low-level tools"),
    "PRIORITY_BATCH" : (201, None, "Specifies that this transaction should be treated as low priority and that default priority transactions should be processed first. Useful for doing batch work simultaneously with latency-sensitive work"),
    "INITIALIZE_NEW_DATABASE" : (300, None, "This is a write-only transaction which sets the initial configuration"),
    "DEBUG_DUMP" : (400, None, ""),
}

StreamingMode = {
    "WANT_ALL" : (-2, None, "Client intends to consume the entire range and would like it all transferred as early as possible."),
    "ITERATOR" : (-1, None, "The default. The client doesn't know how much of the range it is likely to used and wants different performance concerns to be balanced. Only a small portion of data is transferred to the client initially (in order to minimize costs if the client doesn't read the entire range), and as the caller iterates over more items in the range larger batches will be transferred in order to minimize latency."),
    "EXACT" : (0, None, "Infrequently used. The client has passed a specific row limit and wants that many rows delivered in a single batch. Because of iterator operation in client drivers make request batches transparent to the user, consider WANT_ALL StreamingMode instead. A row limit must be specified if this mode is used."),
    "SMALL" : (1, None, "Infrequently used. Transfer data in batches small enough to not be much more expensive than reading individual rows, to minimize cost if iteration stops early."),
    "MEDIUM" : (2, None, "Infrequently used. Transfer data in batches sized in between small and large. Usually the default"),
    "LARGE" : (3, None, "Infrequently used. Transfer data in batches large enough to be, in a high-concurrency environment, nearly as efficient as possible. If the client stops iteration early, some disk and network bandwidth may be wasted. The batch size may still be too small to allow a single client to get high throughput from the database, so if that is what you need consider the SERIAL StreamingMode."),
    "SERIAL" : (4, None, "Transfer data in batches large enough that an individual client can get reasonable read bandwidth from the database. If the client stops iteration early, considerable disk and network bandwidth may be wasted."),
}


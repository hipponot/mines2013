# FoundationDB Backup Agent
# Copyright 2012 FoundationDB, LLC. All Rights Reserved.
#
# This is a confidential non-public alpha version of FoundationDB's
# software. Participation in this alpha testing program is by
# invitation only and the possession, use, and replication of the
# FoundationDB software is subject to the FoundationDB Alpha Software 
# Evaluation License Agreement, which can be found at
# http://foundationdb.com/AlphaLicenseAgreement.pdf
#
# Documentation for this tool can be found at
# http://alpha.foundationdb.com/documentation/administration.html#backup-and-restore

import fdb
fdb.api_version(14)

def read_committed( db, range, group_by = None, terminator = False, streaming_mode = fdb.StreamingMode.iterator, with_each_transaction = None ):
    """Reads range from db with "read committed" isolation (i.e. without snapshot isolation).
    Items are yielded as they are read, and each returned item might be at a different database version.
    There are no items in the database between the keys of adjacent items at the version of the later item.
    
    If the optional group_by parameter is specified, it should be a function accepting a key (byte string)
    and returning a value of any type.  A new item will be returned each time group_by(key) changes between
    sequential key/value pairs (as with itertools.groupby).
    All of the key/value pairs making up an item will be read at the same database version (snapshot
    isolation) and thus must be reasonable in size.  If this is not needed, you could use
    itertools.groupby( read_committed(db,range), ... )
        Each item will have the attributes
            .items is a sequence of fdb.KeyValue objects representing the key/value pairs in the group.
            .group_key == group_by(.items[i].k) for any i
            .version is the database version that all of the items in the group were read at.

    If group_by is not specified, each item will be an individual key/value pair, with the attributes
        .key
        .value
        .version

    If terminator = True, an extra item is yielded at the end with a .version attribute (but no .key,
        .value, .group_key, .items, etc).  This gives the version at which there are no keys in the
        remainder of the range.
        """
    class Group(object):
        def __init__(self):
            self.items = []

    class Terminator(object):
        pass
    
    nextKey = range.start
    while True:
        tr = db.create_transaction()
        try:
            if with_each_transaction:
                with_each_transaction(tr)
            ver = tr.get_read_version().wait()

            if group_by:
                group = None
                skip_group = None

                for item in tr.get_range( nextKey, range.stop, streaming_mode = streaming_mode ):
                    gk = group_by(item.key)
                    if gk == skip_group: continue
                    if not group:
                        group = Group()
                        group.version = ver
                        group.group_key = gk
                    elif group.group_key != gk:
                        yield group

                        # If the transaction fails after this, we can pick up after the last item of
                        # the group we just returned, but we need to ignore any new items added to that
                        # group.  We can't skip right to item.key, because in the new snapshot that could
                        # be in the middle of an item!
                        nextKey = fdb.KeySelector.first_greater_than( group.items[-1].key )
                        skip_group = group.group_key
                        
                        group = Group()
                        group.version = ver
                        group.group_key = gk

                    group.items.append( item )
                    
                # We hit range.stop, so we can safely output the last group
                if group:
                    yield group
                if terminator:
                    group = Terminator()
                    group.version = ver
                    yield group
                break
            else:
                for item in tr.get_range( nextKey, range.stop, streaming_mode = streaming_mode ):
                    item.version = ver
                    yield item
                    nextKey = item.key
                item = Terminator()
                item.version = ver
                yield item
                break
        except fdb.FDBError, err:
            tr.on_error(err.code).wait()  # Rethrows serious errors that can't be retried
            # We have a retryable database error.  Continue with a new transaction.
            # nextKey and skip_group have already been set appropriately

if __name__ == '__main__':
    import struct, time
    
    db = fdb.open()
    if 0:
        print "Inserting"
    for g in range(100):
        @fdb.transactional
        def ins(tr):
            for i in range(1000):
                tr["test/" + struct.pack(">II",g,i)] = str(g) + "," + str(i)
        ins(db)

    print "Reading"
    for kv in read_committed(db, slice("test/","test0"), group_by=lambda x:struct.unpack(">II",x[5:])[0]):
        print kv.version, kv.group_key, len(kv.items)
        time.sleep(0.25)
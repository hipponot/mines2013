# FoundationDB Backup Agent
# Copyright 2012 FoundationDB, LLC. All Rights Reserved.
#
# This is a confidential non-public alpha version of FoundationDB's
# software. Participation in this alpha testing program is by
# invitation only and the possession, use, and replication of the
# FoundationDB software is subject to the FoundationDB Alpha Software 
# Evaluation License Agreement, which can be found at
# http://foundationdb.com/AlphaLicenseAgreement.pdf
#
# Documentation for this tool can be found at
# http://alpha.foundationdb.com/documentation/administration.html#backup-and-restore

"""This module knows how to decode internal backup data that is stored in the
private '\xff' keyspace of FoundationDB.  The format of this data is not formally
documented and may change from version to version of FoundationDB, so this
file represents a very fragile kind of knowledge."""

import fdb, struct
from jenkinshash import hashlittle
fdb.api_version(14)

@fdb.transactional
def check_version(tr):
    """Checks the database to make sure that this module knows how to decode
    its backup data format."""
    ver = int(tr["\xff/backupDataFormat"] or "0")
    if not 1 <= ver <= 1:
        raise Exception("Incompatible version of FoundationDB")

def get_log_ranges(beginVersion, endVersion):
    """Transaction log data is stored by the FoundationDB core in the
    \xff/bklog/ keyspace in a funny order for performance reasons.
    Return the ranges of keys that contain the data for the given range
    of versions."""
    prefix = "\xff/bklog/"
    for vblock in range(beginVersion // 1000, (endVersion + 999) // 1000):
        bv = max(beginVersion, vblock * 1000)
        ev = min(endVersion, (vblock + 1) * 1000)
        vblock_prefix = prefix + struct.pack("<I", hashlittle(struct.pack("<I", vblock & 0xffffffff)))
        yield slice(vblock_prefix + struct.pack(">Q", bv),
                     vblock_prefix + struct.pack(">Q", ev))

def decode_bklog_key(k):
    """Given a key from one of the ranges returned by get_log_ranges,
    returns (version, part) where version is the database version number of
    the transaction log data in the value, and part is 0 for the first such
    data for a given version, 1 for the second block of data, etc."""
    return struct.unpack(">QI", k[12:])

def decode_bklog_value(value):
    """value is an iterable representing all of the transaction log data for
    a given version.  Returns an iterable (generator) yielding a tuple for
    each mutation in the log.  At present, all mutations are represented as
        (type, param1, param2)
    where type is an integer and param1 and param2 are byte strings."""
    value = iter(value)

    try:
        protocolversion, = struct.unpack("<Q", ''.join(next(value) for i in range(8)))
        if not 0x0FDB00A200090001 <= protocolversion:
            raise ValueError("Incompatible version of FoundationDB")

        totalBytes, = struct.unpack("<I", ''.join(next(value) for i in range(4)))
        consumed = 0
        while consumed < totalBytes:
            header = ''.join(next(value) for i in range(12))
            t, len1, len2 = struct.unpack("<III", header)

            val1 = ''.join(next(value) for i in range(len1))
            val2 = ''.join(next(value) for i in range(len2))

            yield (t, val1, val2)
            consumed += len(header) + len(val1) + len(val2)

        assert consumed == totalBytes
        
        if next(value, None) != None:
            raise Exception("Unexpected extra data in decode_bklog_value")
        
    except StopIteration:
        raise ValueError("Unexpected EOF in decode_bklog_value")
